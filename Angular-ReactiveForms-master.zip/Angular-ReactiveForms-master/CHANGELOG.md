#Changes made to the course since its release:
- None.

#Changes made to the project files since its release:
- July 27, 2018 - APM-Updated were modified to Angular v6, RxJS v6, Bootrap v4, and FontAwesome. The changes include moving the code from systemjs to the Angular CLI and all of the new style classes for Bootrap 4.
- July 27, 2018 - Demo-Start-Updated and Demo-Final-Updated were modified to Angular v6 and Bootrap v4. The changes include moving the code from systemjs to the Angular CLI and all of the new style classes for Bootrap 4.

- March 24, 2017 - APM-Updated was added. This is an update to the sample application for Angular version 4. The changes include modifications to the boilerplate files and the addition of an src folder to make these files compatible with the current version of the Angular Quick Start files.
- March 24, 2017 - Demo-Start-Updated and Demo-Final-Updated were added. These are an update to the demo application for Angular version 4. The changes include modifications to the boilerplate files and the addition of an src folder to make these files compatible with the current version of the Angular Quick Start files.
